<!DOCTYPE html>
<html lang="de">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="/style/style.css" type="text/css" rel="stylesheet" />
		<link rel="icon" href="/sys_img/favicon.ico">
		<title>MinecraftServerAdmin.net</title>
		
	</head>	