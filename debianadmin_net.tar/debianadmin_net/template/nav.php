	<body>
		<nav id="nav">
			<div></div>
			<ul class="nav_list">
				<li class="nav_list_element1"><a href="#">Einführung in Debian GNU</a></li>
				<li class="sub nav_list_element1"><a href="#">Server-Security</a></li>
				<li class="sub nav_list_element1"><a href="#">Lorem Ipsum</a></li>
				<li class="sub2 nav_list_element1"><a href="#">Lorem Ipsum</a></li>
				<li class="sub3 nav_list_element1"><a href="#">Lorem Ipsum</a></li>
				<li class="sub2 nav_list_element1"><a href="#">Lorem Ipsum</a></li>
				<li class="sub nav_list_element1"><a href="#">Lorem Ipsum</a></li>
				<li class="sub nav_list_element1"><a href="#">Lorem Ipsum</a></li>
				<li class="nav_list_element2"><a href="#">LAMP/Webserver</a></li>
		<!--	<li class="nav_list_element3"><a href="#">Mailserver</a></li> -->
				<li class="nav_list_element4"><a href="#">Gameserver/Minecraft</a></li>
				<li class="nav_list_element5"><a href="#">Diverse Programme</a></li>
		<!--	<li class="nav_list_element6"><a href="#">Lorem Ipsum</a></li>
				<li class="nav_list_element7"><a href="#">Lorem Ipsum</a></li> -->
				<li class="nav_list_element8"><a href="#">Sonstiges</a></li>	
				<li class="sub nav_list_element8"><a href="/sonstiges/lokale-webseiten-unter-apache.php">Apache2: Lokale Webseiten</a></li>					
			</ul>		
		</nav>
		<div id="grayarea"></div>